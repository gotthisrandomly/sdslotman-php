
<!DOCTYPE html>
<html>
<head> 
    <meta charset="utf-8">
    <title>Betux</title>
    <meta name="viewport" content="width=device-width, user-scalable=yes">
    <link rel="stylesheet" type="text/css" href="css/style.css?v=1670769076">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700;800;900&Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@800&display=swap" rel="stylesheet">

     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     
</head>

 <div class="body_404">
 	<div class="panel_404">
        <form method="POST">
            <input type="" class="secodary_input" placeholder="Код доступа" name="code_auth" style="border:3px solid #7D7AFF;"><br>

            <button class="btn_bet_dice" style="width:154px;margin-top: 10px;" type="submite">Войти</button>
        </form>
	
 	</div>
 	
 </div>

 </html>