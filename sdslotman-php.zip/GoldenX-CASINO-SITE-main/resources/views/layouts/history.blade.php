<div class="history">
        <table>
            <thead>
                <tr>
                    <td>Игра</td>
                    <td>Игрок</td>
                    <td>Ставка</td>
                    <td>Коэфф.</td>
                    <td>Выигрыш</td>
                </tr>
            </thead>
            <tbody class="gameHistory">
                
            </tbody>
        </table>
    </div>