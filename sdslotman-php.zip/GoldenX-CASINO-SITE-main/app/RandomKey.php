<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RandomKey extends Model
{
    protected $guarded = [];
}
