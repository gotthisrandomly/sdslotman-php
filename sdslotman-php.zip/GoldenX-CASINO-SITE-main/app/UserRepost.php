<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserRepost extends Model
{
    protected $guarded = [];
}
