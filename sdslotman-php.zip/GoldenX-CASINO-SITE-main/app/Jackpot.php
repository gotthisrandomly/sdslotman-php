<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jackpot extends Model
{
    protected $guarded = [];
    protected $table = 'jackpot';
}
