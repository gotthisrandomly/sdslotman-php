<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResultRandom extends Model
{
    protected $guarded = [];
    protected $table = 'results_random';
}
