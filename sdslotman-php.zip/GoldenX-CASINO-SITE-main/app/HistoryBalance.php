<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HistoryBalance extends Model
{
        protected $guarded = [];

}
