<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SystemWithdraw extends Model
{
    protected $guarded = [];
    protected $table = 'system_withdraw';
}
