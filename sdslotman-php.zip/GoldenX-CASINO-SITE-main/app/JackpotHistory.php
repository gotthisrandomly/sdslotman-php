<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JackpotHistory extends Model
{
    protected $guarded = [];
    protected $table = 'jackpot_history';
}
 