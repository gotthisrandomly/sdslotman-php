<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SystemDep extends Model
{
    protected $guarded = [];
    protected $table = 'system_dep';
}
