<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Authorization extends Model
{
        protected $guarded = [];

}
